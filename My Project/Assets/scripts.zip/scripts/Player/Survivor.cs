using UnityEngine;

public class Survivor : MonoBehaviour
{
    [Header("Player Settings")]
    public string playerName = "Игрок";
    public int health = 100;

    [Header("Inventory")]
    public int wood = 0;
    public int stone = 0;
    public int food = 0;

    // === Базовые действия ===
    public void CollectResource(string resourceType)
    {
        switch (resourceType.ToLower())
        {
            case "wood":
                wood++;
                Debug.Log($"{playerName} собрал дерево. Всего: {wood}");
                break;
            case "stone":
                stone++;
                Debug.Log($"{playerName} собрал камень. Всего: {stone}");
                break;
            case "food":
                food++;
                Debug.Log($"{playerName} собрал еду. Всего: {food}");
                break;
            default:
                Debug.Log($"{playerName} попытался собрать неизвестный ресурс.");
                break;
        }
    }

    public void Build(string buildingType)
    {
        switch (buildingType.ToLower())
        {
            case "campfire":
                if (wood >= 2 && stone >= 1)
                {
                    wood -= 2;
                    stone -= 1;
                    Debug.Log($"{playerName} построил костёр.");
                }
                else
                {
                    Debug.Log($"{playerName} не хватает ресурсов для костра!");
                }
                break;

            case "shelter":
                if (wood >= 3)
                {
                    wood -= 3;
                    Debug.Log($"{playerName} построил шалаш.");
                }
                else
                {
                    Debug.Log($"{playerName} не хватает дерева для шалаша!");
                }
                break;

            case "storage":
                if (wood >= 2 && stone >= 1)
                {
                    wood -= 2;
                    stone -= 1;
                    Debug.Log($"{playerName} построил склад.");
                }
                else
                {
                    Debug.Log($"{playerName} не хватает ресурсов для склада!");
                }
                break;

            default:
                Debug.Log($"{playerName} не знает, как построить {buildingType}");
                break;
        }
    }

    public void TakeDamage(int damage)
    {
        health -= damage;
        Debug.Log($"{playerName} получил {damage} урона. HP: {health}");

        if (health <= 0)
        {
            Die();
        }
    }

    protected void Die()
    {
        Debug.Log($"{playerName} погиб!");
        // здесь можно вызвать удаление объекта игрока
    }
}
